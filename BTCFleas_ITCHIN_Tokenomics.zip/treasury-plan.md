# Treasury Usage Plan

The treasury (15%) will support:
- Development + Maintenance
- Team compensation
- Future growth incentives
- Emergency reserves

Controlled via multisig or governance structure TBD.

