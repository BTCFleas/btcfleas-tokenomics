# Staking Model

- 1 point earned per block per locked Flea
- Points convert to $ITCHIN at a rate defined by the project (e.g., 10 $ITCHIN per point)
- Emissions capped at 240,000,000 $ITCHIN
- Rewards are claimable periodically through BiS staking interface

