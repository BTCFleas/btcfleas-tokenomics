# Bonding Curve Model

- Starting price: 1 sat per $ITCHIN
- Price increases every 1M tokens sold
- Curve type: Linear or Exponential (to be finalized)
- 100% of BTC raised goes to the project treasury

