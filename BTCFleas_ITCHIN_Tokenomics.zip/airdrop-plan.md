# Airdrop Plan

28% of the total supply is allocated to Flea holders.
Distribution Options:
- Instant airdrop per flea
- Vesting unlock over time
- Bonus for OG wallets or early lockers

